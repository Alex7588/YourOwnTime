import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TimezoneData, formatTime } from '@/lib/timezones';

interface WorldClockProps {
  timezoneData: TimezoneData;
}

const WorldClock: React.FC<WorldClockProps> = ({ timezoneData }) => {
  const [timeInfo, setTimeInfo] = useState(() => formatTime(timezoneData.timezone));

  useEffect(() => {
    const updateTime = () => {
      setTimeInfo(formatTime(timezoneData.timezone));
    };

    // Update immediately
    updateTime();

    // Update every second
    const interval = setInterval(updateTime, 1000);

    return () => clearInterval(interval);
  }, [timezoneData.timezone]);

  return (
    <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300 hover:scale-105 hover:shadow-xl">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{timezoneData.flag}</span>
            <div>
              <div className="font-bold text-lg">{timezoneData.city}</div>
              <div className="text-sm font-normal text-purple-100">{timezoneData.country}</div>
            </div>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-2">
          <div className="text-3xl font-mono font-bold text-white tracking-wider">
            {timeInfo.time}
          </div>
          <Badge variant="secondary" className="bg-purple-200/20 text-purple-100 border-purple-300/30">
            {timeInfo.date}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
};

export default WorldClock;