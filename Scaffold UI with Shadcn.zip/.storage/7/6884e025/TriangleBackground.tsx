import React from 'react';

const TriangleBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Base purple gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900"></div>
      
      {/* Triangular patterns */}
      <div className="absolute inset-0">
        {/* Large triangles */}
        <div className="absolute top-0 left-0 w-0 h-0 border-l-[200px] border-l-transparent border-r-[200px] border-r-transparent border-b-[300px] border-b-purple-700/30"></div>
        <div className="absolute top-20 right-0 w-0 h-0 border-l-[150px] border-l-transparent border-r-[150px] border-r-transparent border-b-[200px] border-b-purple-600/20"></div>
        <div className="absolute bottom-0 left-1/4 w-0 h-0 border-l-[250px] border-l-transparent border-r-[250px] border-r-transparent border-t-[350px] border-t-purple-500/25"></div>
        <div className="absolute bottom-10 right-1/3 w-0 h-0 border-l-[180px] border-l-transparent border-r-[180px] border-r-transparent border-t-[250px] border-t-purple-400/20"></div>
        
        {/* Medium triangles */}
        <div className="absolute top-1/3 left-1/3 w-0 h-0 border-l-[100px] border-l-transparent border-r-[100px] border-r-transparent border-b-[150px] border-b-purple-300/15"></div>
        <div className="absolute top-2/3 right-1/4 w-0 h-0 border-l-[120px] border-l-transparent border-r-[120px] border-r-transparent border-t-[180px] border-t-purple-200/10"></div>
        
        {/* Small triangles */}
        <div className="absolute top-1/4 right-1/2 w-0 h-0 border-l-[60px] border-l-transparent border-r-[60px] border-r-transparent border-b-[80px] border-b-purple-100/20"></div>
        <div className="absolute bottom-1/3 left-1/2 w-0 h-0 border-l-[80px] border-l-transparent border-r-[80px] border-r-transparent border-t-[100px] border-t-purple-50/15"></div>
        
        {/* Floating triangular shapes */}
        <div className="absolute top-1/2 left-10 w-0 h-0 border-l-[40px] border-l-transparent border-r-[40px] border-r-transparent border-b-[60px] border-b-white/10 animate-pulse"></div>
        <div className="absolute top-3/4 right-20 w-0 h-0 border-l-[50px] border-l-transparent border-r-[50px] border-r-transparent border-t-[70px] border-t-white/8 animate-pulse delay-1000"></div>
      </div>
      
      {/* Subtle overlay for depth */}
      <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent"></div>
    </div>
  );
};

export default TriangleBackground;