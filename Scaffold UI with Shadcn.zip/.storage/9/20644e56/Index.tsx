import React from 'react';
import { Clock } from 'lucide-react';
import WorldClock from '@/components/WorldClock';
import TriangleBackground from '@/components/TriangleBackground';
import { worldTimezones } from '@/lib/timezones';

export default function Index() {
  return (
    <div className="min-h-screen relative">
      <TriangleBackground />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Clock className="w-12 h-12 text-white" />
            <h1 className="text-6xl font-bold text-white tracking-tight">
              YOUROWNTIME
            </h1>
          </div>
          <p className="text-xl text-purple-100 max-w-2xl mx-auto">
            Discover the exact time, day, and date for countries around the world. 
            Stay connected across all time zones.
          </p>
        </div>

        {/* World Clocks Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {worldTimezones.map((timezone, index) => (
            <WorldClock 
              key={`${timezone.timezone}-${index}`} 
              timezoneData={timezone} 
            />
          ))}
        </div>

        {/* Footer */}
        <div className="text-center mt-16 text-purple-200">
          <p className="text-sm">
            Real-time updates • {worldTimezones.length} time zones • Built with ❤️
          </p>
        </div>
      </div>
    </div>
  );
}