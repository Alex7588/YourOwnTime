# YOUROWNTIME - World Clock Website

## MVP Features
1. Display current time, day, and date for multiple countries/timezones
2. Purple background with triangular pattern design
3. Responsive grid layout for different time zones
4. Real-time clock updates
5. Clean, modern UI using Shadcn components

## Files to Create/Modify
1. `src/pages/Index.tsx` - Main homepage with world clocks
2. `src/components/WorldClock.tsx` - Individual clock component
3. `src/components/TriangleBackground.tsx` - Purple triangular background
4. `index.html` - Update title to "YOUROWNTIME"
5. `src/lib/timezones.ts` - Timezone data and utilities

## Implementation Plan
- Use JavaScript Date and Intl APIs for timezone handling
- Create reusable clock components
- Implement CSS triangular background pattern
- Use React hooks for real-time updates
- Responsive design with Tailwind CSS